#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="${HOPE_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
cd "$ROOT"

fail() { echo "BOOTSTRAP-FAIL: $*" >&2; exit 1; }
pass() { echo "BOOTSTRAP-PASS: $*"; }

[[ -f "$ROOT/pubspec.yaml" ]] || fail "pubspec.yaml not found at project root"
[[ -d "$ROOT/lib" ]] || fail "lib/ not found at project root"
[[ -d "$ROOT/backend" ]] || fail "backend/ not found at project root"
[[ -f "$ROOT/backend/package.json" ]] || fail "backend/package.json not found"
[[ -f "$ROOT/backend/package-lock.json" ]] || fail "backend/package-lock.json not found"

command -v node >/dev/null || fail "Node.js is required"
command -v npm >/dev/null || fail "npm is required"
command -v flutter >/dev/null || fail "Flutter is required"
command -v python3 >/dev/null || fail "Python 3 is required"
command -v bash >/dev/null || fail "bash is required"

pass "project root: $ROOT"
node --version
npm --version
flutter --version | sed -n '1,2p'

# Restore executable permissions expected by CI/release tests.
chmod +x \
  "$ROOT/backend/entrypoint.sh" \
  "$ROOT/android/gradlew" \
  "$ROOT/tools/"*.sh \
  "$ROOT/tools/"*.py 2>/dev/null || true
pass "executable permissions normalized"

pushd "$ROOT/backend" >/dev/null
npm ci
node --check src/server.js
node --check src/app.js
node --check src/db.js
npm run test:fast
npm run test:contract
npm audit --audit-level=high
popd >/dev/null

flutter pub get
bash "$ROOT/tools/verify-pubspec-lock-fresh.sh"
flutter analyze
flutter test --no-pub

# Final repository-shape guards.
python3 - <<'PY'
from pathlib import Path
root = Path.cwd()
required = [
    'pubspec.yaml', 'pubspec.lock', 'lib', 'backend',
    'backend/package.json', 'backend/package-lock.json',
    '.github/workflows/main.yml', 'tools/bootstrap-v8.sh'
]
missing = [p for p in required if not (root / p).exists()]
if missing:
    raise SystemExit('Missing: ' + ', '.join(missing))
print('BOOTSTRAP-PASS: repository shape verified')
PY

printf '\nHOPE V7 BOOTSTRAP COMPLETE\n'
printf 'Root: %s\n' "$ROOT"
printf 'Node: '; node --version
printf 'Flutter: '; flutter --version | head -1
