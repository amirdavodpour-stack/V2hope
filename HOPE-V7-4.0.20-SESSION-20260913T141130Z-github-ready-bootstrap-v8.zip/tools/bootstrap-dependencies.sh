#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
cd "$ROOT"

fail() { echo "BOOTSTRAP_FAIL: $*" >&2; exit 1; }
need_cmd() { command -v "$1" >/dev/null 2>&1 || fail "required command missing: $1"; }

ALLOW_PARTIAL=0
for arg in "$@"; do
  case "$arg" in
    --allow-partial) ALLOW_PARTIAL=1 ;;
    *) fail "unknown argument: $arg" ;;
  esac
done

# CI is always fail-closed: a missing/incorrect Flutter toolchain must fail the
# bootstrap, never silently downgrade to a partial success. --allow-partial is
# only honored outside CI, for local interactive setup.
if [ "${CI:-}" = "true" ] && [ "$ALLOW_PARTIAL" = "1" ]; then
  fail "--allow-partial is not permitted when CI=true; the toolchain must be fully present in CI"
fi

need_cmd node
need_cmd npm

NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
[ "$NODE_MAJOR" = "24" ] || fail "Node 24 required; found $(node -v)"

[ -f backend/package-lock.json ] || fail "backend/package-lock.json missing"
( cd backend && npm ci --ignore-scripts ) || fail "npm ci failed"

if command -v flutter >/dev/null 2>&1; then
  FLUTTER_VERSION="$(flutter --version 2>/dev/null | sed -n '1s/Flutter \([^ ]*\).*/\1/p')"
  [ "$FLUTTER_VERSION" = "3.47.2" ] || fail "Flutter 3.47.2 required; found ${FLUTTER_VERSION:-unknown}"
  flutter pub get --enforce-lockfile
elif [ "$ALLOW_PARTIAL" = "1" ]; then
  echo "BOOTSTRAP_PARTIAL: Flutter SDK 3.47.2 is not installed in this environment; backend dependencies were attempted." >&2
else
  fail "Flutter SDK 3.47.2 is not installed. Re-run with --allow-partial for a local backend-only bootstrap, or install Flutter 3.47.2."
fi

if [ -x android/gradlew ]; then
  echo "BOOTSTRAP_CHECK: Android Gradle launcher present"
else
  fail "android/gradlew is not executable"
fi

printf 'BOOTSTRAP_PASS\nnode=%s\n' "$(node -v)"
