# HOPE-V7 GitHub Bootstrap V8

This repository is prepared to be uploaded as repository-root content. Do **not** upload the ZIP as the only repository file. The contents of this archive must become the GitHub repository root so `.github/`, `backend/`, `lib/`, `pubspec.yaml`, and `tools/` are directly visible at the top level.

## GitHub upload

1. Create/open the repository.
2. Upload the **contents** of this archive, preserving the directory tree.
3. Commit to `main`.
4. In **Settings → Secrets and variables → Actions**, create `API_BASE_URL` as an Actions secret containing the HTTPS backend base URL.
5. Push/commit. The existing `.github/workflows/main.yml` will run the CI gate.

## Local/Codespace bootstrap

From the repository root:

```bash
bash tools/bootstrap-v8.sh
```

The script is intentionally idempotent for dependencies and read-only application validation. It performs:

- repository-shape validation
- Node/npm/Flutter toolchain checks
- executable-permission normalization
- `npm ci`
- backend syntax checks
- `test:fast`
- `test:contract`
- high-severity `npm audit`
- Flutter dependency refresh
- pubspec lock freshness check
- `flutter analyze`
- `flutter test --no-pub`

## GitHub Actions bootstrap expectations

The workflow expects the repository root to contain `backend/` and `pubspec.yaml`; it must not need to discover or unzip a source archive at runtime. This avoids the root-detection problem from the earlier bootstrap run.
