part of 'home_page.dart';

class _VisualHero extends StatelessWidget {
  const _VisualHero(this.context,
      {required this.settings, required this.onOpenExplore});
  final BuildContext context;
  final HopeSettingsController settings;
  final VoidCallback onOpenExplore;
  @override
  Widget build(BuildContext context) => ClipRRect(
      borderRadius: BorderRadius.circular(30),
      child: SizedBox(
          height: 250,
          child: Stack(fit: StackFit.expand, children: [
            Image.asset('assets/images/hope_marketplace_hero.png',
                fit: BoxFit.cover),
            DecoratedBox(
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                  Colors.black.withValues(alpha: .05),
                  Colors.black.withValues(alpha: .74)
                ]))),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SoftPill(
                        icon: Icons.location_on_rounded,
                        label: settings.city,
                        color: Colors.white),
                    const Spacer(),
                    Text(
                        HopeCopy.of(context)
                            .copy_opportunities_may_already_be_nearby_585bbac,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            height: 1.08,
                            fontWeight: FontWeight.w900)),
                    const SizedBox(height: 7),
                    Text(
                        HopeCopy.of(context)
                            .copy_start_with_your_city_or_explore_any_other__05a1e84,
                        style: const TextStyle(
                            color: Colors.white70, height: 1.45)),
                    const SizedBox(height: 14),
                    SizedBox(
                        width: 150,
                        child: FilledButton(
                            onPressed: onOpenExplore,
                            style: FilledButton.styleFrom(
                                backgroundColor: Colors.white,
                                foregroundColor: AppColors.primary),
                            child: Text(
                                HopeCopy.of(context).copy_explore_a80d678))),
                  ]),
            ),
          ])));
}

class _BigAction extends StatelessWidget {
  const _BigAction(
      {required this.icon,
      required this.title,
      required this.text,
      required this.color,
      required this.onTap});
  final IconData icon;
  final String title;
  final String text;
  final Color color;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => PressableScale(
      onTap: onTap,
      semanticLabel: '$title. $text',
      child: HopeSurface(
          highlight: true,
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            HopeIconTile(icon, filled: true, color: color, size: 48),
            const SizedBox(width: 11),
            Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                  Text(title, style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 3),
                  Text(text, style: Theme.of(context).textTheme.bodyMedium)
                ]))
          ])));
}

class _RecommendationCard extends StatelessWidget {
  const _RecommendationCard(this.context, this.city);
  final BuildContext context;
  final String city;
  @override
  Widget build(BuildContext context) => HopeSurface(
      padding: const EdgeInsets.all(16),
      child: Row(children: [
        HopeIconTile(Icons.near_me_rounded,
            filled: true, color: secondaryAccent(context), size: 48),
        const SizedBox(width: 12),
        Expanded(
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(HopeCopy.of(context).copy_opportunities_near_9da643a,
              style: Theme.of(context).textTheme.bodyMedium),
          Text(city, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 3),
          Text(
              HopeCopy.of(context)
                  .copy_location_personalization_is_on_you_can_cha_8dd12f4,
              style: Theme.of(context).textTheme.bodyMedium)
        ]))
      ]));
}
