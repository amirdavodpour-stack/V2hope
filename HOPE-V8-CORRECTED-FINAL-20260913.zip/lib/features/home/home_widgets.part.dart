part of 'home_page.dart';

class _HomeFeed extends StatelessWidget {
  const _HomeFeed({required this.onOpenExplore});
  final VoidCallback onOpenExplore;

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    final settings = context.watch<HopeSettingsController>();
    final name = auth.isGuest
        ? HopeCopy.of(context).copy_hope_friend_b997e02
        : '${auth.user?['displayName'] ?? HopeCopy.of(context).copy_hope_friend_b997e02}';
    return HopeResponsive(
        child: ListView(
            padding: const EdgeInsets.fromLTRB(0, 16, 0, 122),
            children: [
          Row(children: [
            const Expanded(child: HopeMark()),
            IconButton(
                onPressed: () => Scaffold.of(context).openDrawer(),
                icon: const Icon(Icons.menu_rounded),
                tooltip: HopeCopy.of(context).copy_menu_1f381a4)
          ]),
          const SizedBox(height: 24),
          AnimatedEntrance(
            child: Text('${HopeCopy.of(context).copy_hello_fc7ef4a} $name 👋',
                style: Theme.of(context).textTheme.displaySmall),
          ),
          const SizedBox(height: 6),
          AnimatedEntrance(
            delay: const Duration(milliseconds: 40),
            child: Text(
                HopeCopy.of(context)
                    .copy_a_clearer_more_human_way_to_find_work_3553ab8,
                style: Theme.of(context).textTheme.bodyLarge),
          ),
          const SizedBox(height: 18),
          AnimatedEntrance(
            delay: const Duration(milliseconds: 90),
            child: _VisualHero(context,
                settings: settings, onOpenExplore: onOpenExplore),
          ),
          const SizedBox(height: 20),
          AnimatedEntrance(
            delay: const Duration(milliseconds: 140),
            child: Row(children: [
              Expanded(
                  child: _BigAction(
                      icon: Icons.bolt_rounded,
                      title: HopeCopy.of(context).copy_missions_a833d13,
                      text: HopeCopy.of(context)
                          .copy_defined_tasks_with_clear_pay_9120d5e,
                      color: AppColors.primary,
                      onTap: onOpenExplore)),
              const SizedBox(width: 10),
              Expanded(
                  child: _BigAction(
                      icon: Icons.business_center_rounded,
                      title: HopeCopy.of(context).copy_jobs_ebf9a80,
                      text: HopeCopy.of(context)
                          .copy_part_time_or_full_time_a007875,
                      color: secondaryAccent(context),
                      onTap: onOpenExplore))
            ]),
          ),
          const SizedBox(height: 22),
          SectionTitle(
              title: HopeCopy.of(context).copy_recommended_for_you_e56d06b,
              subtitle: HopeCopy.of(context)
                  .copy_based_on_your_city_and_preferences_79e2a31),
          const SizedBox(height: 11),
          AnimatedEntrance(
            delay: const Duration(milliseconds: 180),
            child: _RecommendationCard(context, settings.city),
          ),
          const SizedBox(height: 20),
          AnimatedEntrance(
            delay: const Duration(milliseconds: 220),
            child: HopeSurface(
                padding: const EdgeInsets.all(18),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(HopeCopy.of(context).copy_how_hope_works_bea7074,
                          style: Theme.of(context).textTheme.titleLarge),
                      const SizedBox(height: 12),
                      _step(
                          context,
                          '۱',
                          HopeCopy.of(context).copy_choose_79a9d79,
                          HopeCopy.of(context)
                              .copy_decide_whether_you_want_a_mission_or_a_job_3a6f9b5),
                      _step(
                          context,
                          '۲',
                          HopeCopy.of(context).copy_explore_837e4eb,
                          HopeCopy.of(context)
                              .copy_filter_by_city_field_and_opportunity_type_1d75340),
                      _step(
                          context,
                          '۳',
                          HopeCopy.of(context).copy_apply_1b61105,
                          HopeCopy.of(context)
                              .copy_apply_with_a_strong_professional_profile_13980b1),
                    ])),
          ),
        ]));
  }

  Widget _step(BuildContext context, String n, String title, String text) =>
      Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Row(children: [
            Container(
                width: 31,
                height: 31,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    color: AppColors.primary.withValues(alpha: .1),
                    shape: BoxShape.circle),
                child: Text(n,
                    style: const TextStyle(
                        fontWeight: FontWeight.w900,
                        color: AppColors.primary))),
            const SizedBox(width: 10),
            Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                  Text(title, style: Theme.of(context).textTheme.titleMedium),
                  Text(text, style: Theme.of(context).textTheme.bodyMedium)
                ]))
          ]));
}

class _VisualHero extends StatelessWidget {
  const _VisualHero(this.context,
      {required this.settings, required this.onOpenExplore});
  final BuildContext context;
  final HopeSettingsController settings;
  final VoidCallback onOpenExplore;
  @override
  Widget build(BuildContext context) => ClipRRect(
      borderRadius: BorderRadius.circular(30),
      child: SizedBox(
          height: 250,
          child: Stack(fit: StackFit.expand, children: [
            Image.asset('assets/images/hope_marketplace_hero.png',
                fit: BoxFit.cover),
            DecoratedBox(
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                  Colors.black.withValues(alpha: .05),
                  Colors.black.withValues(alpha: .74)
                ]))),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SoftPill(
                        icon: Icons.location_on_rounded,
                        label: settings.city,
                        color: Colors.white),
                    const Spacer(),
                    Text(
                        HopeCopy.of(context)
                            .copy_opportunities_may_already_be_nearby_585bbac,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            height: 1.08,
                            fontWeight: FontWeight.w900)),
                    const SizedBox(height: 7),
                    Text(
                        HopeCopy.of(context)
                            .copy_start_with_your_city_or_explore_any_other__05a1e84,
                        style: const TextStyle(
                            color: Colors.white70, height: 1.45)),
                    const SizedBox(height: 14),
                    SizedBox(
                        width: 150,
                        child: FilledButton(
                            onPressed: onOpenExplore,
                            style: FilledButton.styleFrom(
                                backgroundColor: Colors.white,
                                foregroundColor: AppColors.primary),
                            child: Text(
                                HopeCopy.of(context).copy_explore_a80d678))),
                  ]),
            ),
          ])));
}

class _BigAction extends StatelessWidget {
  const _BigAction(
      {required this.icon,
      required this.title,
      required this.text,
      required this.color,
      required this.onTap});
  final IconData icon;
  final String title;
  final String text;
  final Color color;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => PressableScale(
      onTap: onTap,
      semanticLabel: '$title. $text',
      child: HopeSurface(
          highlight: true,
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            HopeIconTile(icon, filled: true, color: color, size: 48),
            const SizedBox(width: 11),
            Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                  Text(title, style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 3),
                  Text(text, style: Theme.of(context).textTheme.bodyMedium)
                ]))
          ])));
}

class _RecommendationCard extends StatelessWidget {
  const _RecommendationCard(this.context, this.city);
  final BuildContext context;
  final String city;
  @override
  Widget build(BuildContext context) => HopeSurface(
      padding: const EdgeInsets.all(16),
      child: Row(children: [
        HopeIconTile(Icons.near_me_rounded,
            filled: true, color: secondaryAccent(context), size: 48),
        const SizedBox(width: 12),
        Expanded(
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(HopeCopy.of(context).copy_opportunities_near_9da643a,
              style: Theme.of(context).textTheme.bodyMedium),
          Text(city, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 3),
          Text(
              HopeCopy.of(context)
                  .copy_location_personalization_is_on_you_can_cha_8dd12f4,
              style: Theme.of(context).textTheme.bodyMedium)
        ]))
      ]));
}
