import '../admin/admin_repository.dart';
import '../auth/auth_repository.dart';
import '../notifications/notification_repository.dart';
import '../profile/profile_repository.dart';
import '../marketplace/job_detail_repository.dart';
import '../marketplace/marketplace_repository.dart';
import '../marketplace/job.dart';
import '../marketplace/saved_search_repository.dart';
import '../transactions/transaction_repository.dart';
import 'use_cases.dart';

class ApplicationRegistry {
  const ApplicationRegistry({
    required this.marketplace,
    required this.jobDetail,
    required this.transactions,
    required this.admin,
    required this.auth,
    required this.notifications,
    required this.profile,
    required this.savedSearches,
  });

  final MarketplaceRepository marketplace;
  final JobDetailRepository jobDetail;
  final TransactionRepository transactions;
  final AdminRepository admin;
  final AuthRepository auth;
  final NotificationRepository notifications;
  final ProfileRepository profile;
  final SavedSearchRepository savedSearches;

  CreateOpportunityUseCase get createOpportunity => CreateOpportunityUseCase(marketplace);
  ListCategoriesUseCase get listCategories => ListCategoriesUseCase(marketplace);
  Future<HopeJob> getOpportunity(String id) => marketplace.getOpportunity(id);
  ListOpportunitiesUseCase get listOpportunities => ListOpportunitiesUseCase(marketplace);
  ApplyToJobUseCase get applyToJob => ApplyToJobUseCase(jobDetail);
  SubmitOfferUseCase get submitOffer => SubmitOfferUseCase(jobDetail);
  CandidateActionUseCase get candidateAction => CandidateActionUseCase(jobDetail);
  ListMyJobsUseCase get listMyJobs => ListMyJobsUseCase(transactions);
  LoadTransactionUseCase get loadTransaction => LoadTransactionUseCase(transactions);
  TransactionCommandUseCase get transactionCommand => TransactionCommandUseCase(transactions);
  AdminCommandUseCase get adminCommands => AdminCommandUseCase(admin);
  LoginUseCase get login => LoginUseCase(auth);
  RegisterUseCase get register => RegisterUseCase(auth);
  LogoutUseCase get logout => LogoutUseCase(auth);
  RequestPasswordResetUseCase get requestPasswordReset => RequestPasswordResetUseCase(auth);
  ListNotificationsUseCase get listNotifications => ListNotificationsUseCase(notifications);
  LoadNotificationPreferencesUseCase get loadNotificationPreferences => LoadNotificationPreferencesUseCase(notifications);
  UpdateNotificationPreferencesUseCase get updateNotificationPreferences => UpdateNotificationPreferencesUseCase(notifications);
  MarkNotificationReadUseCase get markNotificationRead => MarkNotificationReadUseCase(notifications);
  MarkAllNotificationsReadUseCase get markAllNotificationsRead => MarkAllNotificationsReadUseCase(notifications);
  LoadProviderProfileUseCase get loadProviderProfile => LoadProviderProfileUseCase(profile);
  ListApplicationsUseCase get listApplications => ListApplicationsUseCase(profile);
  WithdrawApplicationUseCase get withdrawApplication => WithdrawApplicationUseCase(profile);
}
