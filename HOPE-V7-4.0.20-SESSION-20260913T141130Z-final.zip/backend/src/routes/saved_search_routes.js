export function createSavedSearchRoutes({ authUser, db, repo, readBody, sendJson, HttpError, textField, now }) {
  const localList = (userId) => db.collection.savedSearches.filter((x) => x.userId === userId).sort((a,b) => String(b.updatedAt).localeCompare(String(a.updatedAt))).slice(0,20);
  const localUpsert = (userId, body) => {
    const name = textField(body.name, 'name', {min:1,max:100,required:true}).trim();
    const values = {
      id: String(body.id || db.id()), userId, name,
      query: textField(body.query || '', 'query', {min:0,max:240}),
      kind: textField(body.kind || 'ALL', 'kind', {min:1,max:40}),
      visibility: textField(body.visibility || 'ALL', 'visibility', {min:1,max:40}),
      city: textField(body.city || 'AUTO', 'city', {min:1,max:120}),
      category: textField(body.category || 'ALL', 'category', {min:1,max:120}),
      updatedAt: now(), createdAt: now(),
    };
    const existing = db.collection.savedSearches.find((x) => x.userId === userId && (x.id === values.id || x.name.trim().toLowerCase() === name.toLowerCase()));
    if (existing) Object.assign(existing, values, { id: existing.id, createdAt: existing.createdAt || values.createdAt });
    else db.insert('savedSearches', values);
    const all = localList(userId);
    if (all.length > 20) {
      for (const stale of all.slice(20)) db.collection.savedSearches = db.collection.savedSearches.filter((x) => x.id !== stale.id);
    }
    db.touch('savedSearches');
    return db.collection.savedSearches.find((x) => x.userId === userId && x.id === values.id) || db.collection.savedSearches.find((x) => x.userId === userId && x.name.toLowerCase() === name.toLowerCase());
  };

  return async function savedSearchRoutes(req, res, parts) {
    const me = await authUser(req);
    if (req.method === 'GET' && parts.length === 1) {
      const items = process.env.DATABASE_URL ? await repo.listSavedSearches(me.id) : localList(me.id);
      return sendJson(res, 200, {items});
    }
    if (req.method === 'PUT' && parts.length === 1) {
      const body = await readBody(req);
      if (!body || typeof body !== 'object') throw new HttpError(400,'INVALID_BODY','Request body is required');
      const search = process.env.DATABASE_URL
        ? await repo.upsertSavedSearch(me.id, {
            id: body.id ? textField(body.id,'id',{min:1,max:100}) : undefined,
            name: textField(body.name,'name',{min:1,max:100,required:true}),
            query: textField(body.query || '','query',{min:0,max:240}),
            kind: textField(body.kind || 'ALL','kind',{min:1,max:40}),
            visibility: textField(body.visibility || 'ALL','visibility',{min:1,max:40}),
            city: textField(body.city || 'AUTO','city',{min:1,max:120}),
            category: textField(body.category || 'ALL','category',{min:1,max:120}),
          })
        : localUpsert(me.id, body);
      return sendJson(res, 200, search);
    }
    if (req.method === 'DELETE' && parts.length === 2 && parts[1]) {
      const id = textField(parts[1],'id',{min:1,max:100});
      if (process.env.DATABASE_URL) return sendJson(res, 200, await repo.deleteSavedSearch(me.id,id));
      const exists = db.collection.savedSearches.some((x) => x.id === id && x.userId === me.id);
      if (!exists) throw new HttpError(404,'SAVED_SEARCH_NOT_FOUND','Saved search not found');
      db.collection.savedSearches = db.collection.savedSearches.filter((x) => !(x.id === id && x.userId === me.id));
      db.touch('savedSearches');
      return sendJson(res, 200, {deleted:true,id});
    }
    throw new HttpError(404,'NOT_FOUND','Saved search route not found');
  };
}
