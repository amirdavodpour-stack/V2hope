export function createAdminRoutes({ authUser, requireAdmin, readBody, sendJson, HttpError, enumField, repo, adminUseCases, db, config, now, createAudit, findUser, getJob, notifyApplicationCandidate, paymentUseCases, URL }) {
  return async function adminRoutes(req,res,parts){
    const me=requireAdmin(await authUser(req));
    if(req.method==='GET' && parts[0]==='admin' && parts[1]==='finance' && parts.length===3 && parts[2]==='summary'){
      if(process.env.DATABASE_URL){ return sendJson(res,200,await paymentUseCases.adminFinancialSummary()); }
      const payments=db.collection.payments, refunds=db.collection.refunds, settlements=db.collection.settlements, ledger=db.collection.ledgerEntries;
      return sendJson(res,200,{payments:payments.length,pending:payments.filter(p=>['HOLD_PENDING','REFUND_PENDING','RELEASE_PENDING','RELEASE_FAILED'].includes(p.status)).length,held:payments.filter(p=>p.status==='HELD').length,released:payments.filter(p=>p.status==='RELEASED').length,refunded:payments.filter(p=>p.status==='REFUNDED').length,platformFees:payments.reduce((s,p)=>s+Number(p.platformFee||0),0),employerCharges:payments.reduce((s,p)=>s+Number(p.employerCharge||p.amount||0),0),providerPayouts:payments.reduce((s,p)=>s+Number(p.providerPayout||p.amount||0),0),refunds:refunds.length,settlements:settlements.length,ledgerEntries:ledger.length,currency:config.paymentCurrency});
    }
    if(req.method==='GET' && parts[0]==='admin' && parts[1]==='summary'){
      if(process.env.DATABASE_URL){ return sendJson(res,200,await adminUseCases.summary()); }
      const users=db.collection.users, jobs=db.collection.jobs, apps=db.collection.jobApplications;
      return sendJson(res,200,{users:users.length,admins:users.filter(u=>u.role==='ADMIN').length,active_users:users.filter(u=>u.role==='USER'&&u.status==='ACTIVE').length,suspended_users:users.filter(u=>u.status!=='ACTIVE').length,opportunities:jobs.length,published_opportunities:jobs.filter(j=>j.status==='PUBLISHED').length,draft_opportunities:jobs.filter(j=>j.status==='DRAFT').length,missions:jobs.filter(j=>j.kind==='MISSION').length,jobs:jobs.filter(j=>j.kind==='JOB').length,applications:apps.length,pending_applications:apps.filter(a=>['PENDING','SHORTLISTED'].includes(a.status)).length,audit_events:db.collection.audit.length});
    }
    if(req.method==='GET' && parts[0]==='admin' && parts[1]==='users'){
      const u=process.env.DATABASE_URL?await adminUseCases.users():db.collection.users.slice().sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));
      return sendJson(res,200,u.map(x=>({id:x.id,email:x.email,displayName:x.displayName,role:x.role,status:x.status,createdAt:x.createdAt})));
    }
    if(req.method==='POST' && parts[0]==='admin' && parts[1]==='users' && parts[3]==='status'){
      const id=parts[2]; const body=await readBody(req); const status=enumField(body?.status,new Set(['ACTIVE','SUSPENDED']),'status'); if(id===me.id && status==='SUSPENDED') throw new HttpError(400,'SELF_SUSPEND_FORBIDDEN','An admin cannot suspend their own account');
      const updated=process.env.DATABASE_URL?await adminUseCases.setUserStatus(id,status):(()=>{const u=db.collection.users.find(x=>x.id===id); if(!u)return null; u.status=status; u.sessionVersion=Number(u.sessionVersion||0)+1; db.touch('users'); return u;})(); if(!updated) throw new HttpError(404,'USER_NOT_FOUND','User not found'); if(!process.env.DATABASE_URL) await db.save(); await createAudit('ADMIN_USER_STATUS',me.id,'user',id,{status}); return sendJson(res,200,{id,status:updated.status});
    }
    if(req.method==='GET' && parts[0]==='admin' && parts[1]==='trust-reports'){
      const status=req.url?new URL(req.url,'http://localhost').searchParams.get('status'):null;
      if(process.env.DATABASE_URL){ return sendJson(res,200,await adminUseCases.trustReports(status)); }
      const reports=db.collection.trustReports.filter(r=>!status||r.status===status).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));
      return sendJson(res,200,reports.map(r=>({...r,reporterName:findUser(r.reporterId)?.displayName||null})));
    }
    if(req.method==='POST' && parts[0]==='admin' && parts[1]==='trust-reports' && parts[3]==='status'){
      const id=parts[2]; const body=await readBody(req); const status=enumField(body?.status,new Set(['OPEN','REVIEWING','RESOLVED','DISMISSED']),'status');
      const updated=process.env.DATABASE_URL?await adminUseCases.updateTrustReportStatus(id,status):(()=>{const r=db.collection.trustReports.find(x=>x.id===id); if(!r)return null; r.status=status; r.updatedAt=now(); db.touch('trustReports'); return r;})();
      if(!updated) throw new HttpError(404,'REPORT_NOT_FOUND','Trust report not found'); if(!process.env.DATABASE_URL) await db.save();
      await createAudit('TRUST_REPORT_STATUS',me.id,'trust_report',id,{status}); return sendJson(res,200,{id,status:updated.status});
    }
    if(req.method==='GET' && parts[0]==='admin' && parts[1]==='audit'){
      if(process.env.DATABASE_URL){ return sendJson(res,200,await adminUseCases.audit()); }
      const logs=db.collection.audit.slice().sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt))).map(a=>({...a,actorName:findUser(a.actorId)?.displayName||null}));
      return sendJson(res,200,logs);
    }
    if(req.method==='GET' && parts[0]==='admin' && parts[1]==='jobs'){ const jobs=process.env.DATABASE_URL?await adminUseCases.jobs():db.collection.jobs.slice().sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt))); return sendJson(res,200,jobs); }
    if(req.method==='POST' && parts[0]==='admin' && parts[1]==='jobs' && parts[3]==='moderate'){
      const id=parts[2]; const body=await readBody(req); const status=enumField(body?.status,new Set(['DRAFT','PUBLISHED','CANCELLED']),'status');
      const job=await getJob(id); if(!job) throw new HttpError(404,'JOB_NOT_FOUND','Job not found');
      try { const updated=process.env.DATABASE_URL?await adminUseCases.moderateJob(id,status):(()=>{const j=db.collection.jobs.find(x=>x.id===id); if(!j)return null; if(['COMPLETED','ASSIGNED','FUNDED','IN_PROGRESS','DELIVERED','UNDER_REVIEW'].includes(j.status)){const e=new Error('JOB_LOCKED'); e.code='JOB_LOCKED'; throw e;} j.status=status; j.updatedAt=now(); if(status==='PUBLISHED'&&!j.publishedAt) j.publishedAt=now(); db.touch('jobs'); return j;})(); if(!updated) throw new HttpError(404,'JOB_NOT_FOUND','Job not found'); if(!process.env.DATABASE_URL) await db.save(); await createAudit('ADMIN_JOB_MODERATE',me.id,'job',id,{status}); return sendJson(res,200,updated); } catch(e){ if(e?.code==='JOB_LOCKED') throw new HttpError(409,'JOB_LOCKED','This opportunity is already in a protected lifecycle state'); throw e; }
    }
    if(req.method==='DELETE' && parts[0]==='admin' && parts[1]==='jobs' && parts[2]){
      const id=parts[2]; const job=await getJob(id); if(!job) throw new HttpError(404,'JOB_NOT_FOUND','Job not found');
      if(!['DRAFT','PUBLISHED'].includes(job.status)) throw new HttpError(409,'JOB_NOT_DELETABLE','Only draft or published opportunities can be deleted by admins');
      if(process.env.DATABASE_URL) await adminUseCases.deleteJob(id);
      else {
        const financial = db.collection.payments.find(p=>p.jobId===id);
        if (financial) throw new HttpError(409,'JOB_HAS_FINANCIAL_RECORDS','This opportunity has financial records and cannot be deleted');
        db.collection.jobs=db.collection.jobs.filter(j=>j.id!==id); db.collection.offers=db.collection.offers.filter(o=>o.jobId!==id); db.collection.jobApplications=db.collection.jobApplications.filter(a=>a.jobId!==id); db.collection.evidence=db.collection.evidence.filter(e=>e.jobId!==id); db.touch('jobs','offers','jobApplications','evidence'); await db.save();
      }
      await createAudit('ADMIN_JOB_DELETE',me.id,'job',id); return sendJson(res,200,{deleted:true,id});
    }
    if(req.method==='GET' && parts[0]==='admin' && parts[1]==='applications'){ const apps=process.env.DATABASE_URL?await adminUseCases.applications():db.collection.jobApplications.slice().sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt))).map(a=>{const j=db.collection.jobs.find(x=>x.id===a.jobId); const u=findUser(a.candidateId); return {...a,jobTitle:j?.title||'—',candidateName:u?.displayName||'—'};}); return sendJson(res,200,apps); }
    if(req.method==='POST' && parts[0]==='admin' && parts[1]==='applications' && parts[3]==='shortlist'){ const id=parts[2]; const changed=process.env.DATABASE_URL?await adminUseCases.shortlist(id):(()=>{const a=db.collection.jobApplications.find(x=>x.id===id&&x.status==='PENDING'); if(!a)return null; a.status='SHORTLISTED'; a.updatedAt=now(); db.touch('jobApplications'); return a;})(); if(!changed) throw new HttpError(409,'INVALID_APPLICATION_STATE','Application is not pending'); if(!process.env.DATABASE_URL) await db.save(); await notifyApplicationCandidate(id, 'APPLICATION_SHORTLISTED', 'درخواست شما وارد فهرست کوتاه شد', 'درخواست شما برای بررسی بیشتر انتخاب شده است.'); await createAudit('ADMIN_APPLICATION_SHORTLIST',me.id,'job_application',id); return sendJson(res,200,{id,status:changed.status}); }
    if(req.method==='POST' && parts[0]==='admin' && parts[1]==='applications' && parts[3]==='select'){ const id=parts[2]; const changed=process.env.DATABASE_URL?await adminUseCases.forward(id):(()=>{const a=db.collection.jobApplications.find(x=>x.id===id&&['PENDING','SHORTLISTED'].includes(x.status)); if(!a)return null; a.status='FORWARDED'; a.updatedAt=now(); db.touch('jobApplications'); return a;})(); if(!changed) throw new HttpError(409,'INVALID_APPLICATION_STATE','Application cannot be forwarded'); if(!process.env.DATABASE_URL) await db.save(); await notifyApplicationCandidate(id, 'APPLICATION_FORWARDED', 'درخواست شما برای کارفرما ارسال شد', 'رزومه و اطلاعات حرفه‌ای شما برای بررسی کارفرما ارسال شده است.'); await createAudit('ADMIN_APPLICATION_FORWARD',me.id,'job_application',id); return sendJson(res,200,{id,status:changed.status}); }
    if(req.method==='POST' && parts[0]==='admin' && parts[1]==='applications' && parts[3]==='reject'){ const id=parts[2]; const changed=process.env.DATABASE_URL?await adminUseCases.reject(id):(()=>{const a=db.collection.jobApplications.find(x=>x.id===id&&['PENDING','SHORTLISTED'].includes(x.status)); if(!a)return null; a.status='REJECTED'; a.updatedAt=now(); db.touch('jobApplications'); return a;})(); if(!changed) throw new HttpError(409,'INVALID_APPLICATION_STATE','Application cannot be rejected from its current state'); if(!process.env.DATABASE_URL) await db.save(); await notifyApplicationCandidate(id, 'APPLICATION_REJECTED', 'درخواست شما پذیرفته نشد', 'درخواست شما برای این شغل در این مرحله ادامه پیدا نکرد.'); await createAudit('ADMIN_APPLICATION_REJECT',me.id,'job_application',id); return sendJson(res,200,{id,status:changed.status}); }
    throw new HttpError(404,'NOT_FOUND','Admin route not found');
  };
}
