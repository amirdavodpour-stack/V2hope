import crypto from 'node:crypto';
import { verifyTimestampedPayload } from '../webhook_security.js';

const PAYMENT_WEBHOOK_EVENTS = new Set(['PAYMENT_HELD', 'PAYMENT_RELEASED', 'PAYMENT_REFUNDED']);
const eventTypeRequiresProviderRef = (eventType) => ['PAYMENT_HELD', 'PAYMENT_RELEASED'].includes(String(eventType || '').trim().toUpperCase());

export function verifyPaymentWebhookSignature(raw, signature, secret, { timestamp, eventId, maxAgeSeconds = 300, requireTimestamp = true, nowMs = Date.now() } = {}) {
  if (!secret) return false;
  if (requireTimestamp) return verifyTimestampedPayload(raw, signature, secret, { timestamp, eventId, maxAgeSeconds, nowMs });
  const expected = `sha256=${crypto.createHmac('sha256', secret).update(raw).digest('hex')}`;
  const providedBuf = Buffer.from(String(signature || '').trim());
  const expectedBuf = Buffer.from(expected);
  return providedBuf.length === expectedBuf.length && crypto.timingSafeEqual(providedBuf, expectedBuf);
}

export function normalizePaymentWebhookBody(body, { requireFields, enumField }) {
  requireFields(body, ['eventId', 'eventType', 'paymentId']);
  const eventId = String(body.eventId || '').trim();
  const paymentId = String(body.paymentId || '').trim();
  const providerRef = String(body.providerRef || '').trim();
  if (!eventId || eventId.length > 200) throw new Error('INVALID_EVENT_ID');
  if (!paymentId || paymentId.length > 100) throw new Error('INVALID_PAYMENT_ID');
  if (eventTypeRequiresProviderRef(body.eventType) && !providerRef) throw new Error('INVALID_PROVIDER_REF');
  return {
    eventId,
    eventType: enumField(body.eventType, PAYMENT_WEBHOOK_EVENTS, 'eventType'),
    paymentId,
    providerRef,
    payload: body,
  };
}

export async function applyLocalPaymentWebhook({ event, db, withTransaction, config, releaseJournal, payoutJournal, now }) {
  return withTransaction(async () => {
    const duplicate = db.collection.paymentWebhooks.find((x) => x.eventId === event.eventId);
    if (duplicate) return { processed: true, duplicate: true, paymentId: duplicate.paymentId };

    db.insert('paymentWebhooks', {
      id: db.id(),
      eventId: event.eventId,
      eventType: event.eventType,
      paymentId: event.paymentId,
      providerRef: event.providerRef,
      payload: event.payload,
      processedAt: now(),
      createdAt: now(),
    });

    const payment = db.collection.payments.find((x) => x.id === event.paymentId);
    if (!payment) return { processed: true, duplicate: false, paymentId: null };

    if (event.eventType === 'PAYMENT_HELD' && payment.status === 'HOLD_PENDING') {
      payment.status = 'HELD';
      if (event.providerRef) payment.providerRef = event.providerRef;
      db.touch('payments');
    }

    if (event.eventType === 'PAYMENT_RELEASED' && payment.status === 'RELEASE_PENDING') {
      payment.status = 'RELEASED';
      const job = db.collection.jobs.find((x) => x.id === payment.jobId);
      if (job) {
        job.status = 'SETTLED';
        job.updatedAt = now();
        db.touch('jobs');
      }
      const breakdown = {
        baseAmount: payment.baseAmount || payment.amount,
        employerFee: payment.employerFee || 0,
        workerFee: payment.workerFee || 0,
        platformFee: payment.platformFee || 0,
        employerCharge: payment.employerCharge || payment.amount,
        providerPayout: payment.providerPayout || payment.amount,
        currency: payment.currency || config.paymentCurrency,
      };
      for (const journal of [releaseJournal(breakdown), payoutJournal(breakdown)]) {
        const journalId = db.id();
        for (const entry of journal) {
          db.insert('ledgerEntries', {
            id: db.id(),
            journalId,
            referenceType: 'PAYMENT_WEBHOOK',
            referenceId: payment.id,
            account: entry.account,
            debit: entry.debit,
            credit: entry.credit,
            currency: breakdown.currency,
            createdAt: now(),
          });
        }
      }
      db.insert('settlements', {
        id: db.id(),
        paymentId: payment.id,
        providerRef: event.providerRef || payment.providerRef,
        amount: breakdown.providerPayout,
        currency: breakdown.currency,
        status: 'RELEASED',
        createdAt: now(),
        updatedAt: now(),
      });
      db.touch('payments', 'settlements');
    }

    if (event.eventType === 'PAYMENT_REFUNDED' && payment.status === 'REFUND_PENDING') {
      payment.status = 'REFUNDED';
      db.touch('payments');
    }

    return { processed: true, duplicate: false, paymentId: payment.id };
  });
}
