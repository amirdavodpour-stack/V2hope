import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(new URL('..', import.meta.url).pathname);

function read(file) { return fs.readFileSync(path.join(root, file), 'utf8'); }

test('application/domain/infrastructure layers exist with stable boundaries', () => {
  const required = [
    'src/api/request_context.js',
    'src/api/error_envelope.js',
    'src/domain/state_machine.js',
    'src/domain/payment_state.js',
    'src/domain/job_state.js',
    'src/application/ports/repositories.js',
    'src/application/ports/repository_ports.js',
    'src/application/use_cases/marketplace_use_cases.js',
    'src/application/use_cases/payment_use_cases.js',
    'src/infrastructure/adapters/providers.js',
  ];
  for (const file of required) assert.equal(fs.existsSync(path.join(root, file)), true, file);

  const portSlices = read('src/application/ports/repository_ports.js');
  assert.match(portSlices, /createRepositoryPorts/);
  const payment = read('src/application/use_cases/payment_use_cases.js');
  assert.match(payment, /application boundary/i);
  assert.doesNotMatch(payment, /from ['"]\.\.\/\.\.\/db\.js['"]/);

  const flutterUseCases = path.resolve(root, '..', 'lib', 'core', 'application', 'use_cases.dart');
  const flutterRegistry = path.resolve(root, '..', 'lib', 'core', 'application', 'application_registry.dart');
  const flutterMain = path.resolve(root, '..', 'lib', 'main.dart');
  assert.equal(fs.existsSync(flutterUseCases), true, 'lib/core/application/use_cases.dart');
  assert.equal(fs.existsSync(flutterRegistry), true, 'lib/core/application/application_registry.dart');
  const main = fs.readFileSync(flutterMain, 'utf8');
  assert.match(main, /Provider<ApplicationRegistry>/);

  const state = read('src/domain/payment_state.js');
  assert.match(state, /HOLD_PENDING/);
  assert.match(state, /RELEASED/);
});


test('app composition wires use cases before dependent route factories', () => {
  const app = read('src/app.js');
  const portsPos = app.indexOf('const repositoryPorts = createRepositoryPorts(repo);');
  const adminPos = app.indexOf('const adminRoutes = createAdminRoutes({');
  const paymentFactoryPos = app.indexOf('const paymentRoutes = createPaymentRoutes({');
  const adminUseCasePos = app.indexOf('const adminUseCases = createAdminUseCases({ admin: repositoryPorts.admin });');
  assert.ok(portsPos >= 0 && adminUseCasePos > portsPos && adminPos > adminUseCasePos,
    'admin use-cases must be composed before adminRoutes factory');
  assert.ok(paymentFactoryPos >= 0, 'payment route factory must exist');
  const paymentBlock = app.slice(paymentFactoryPos, app.indexOf('\n});', paymentFactoryPos) + 4);
  assert.match(paymentBlock, /paymentUseCases\s*,/,
    'payment route factory must receive the composed paymentUseCases');
});


test('request context is attached once at the transport boundary', () => {
  const app = read('src/app.js');
  assert.match(app, /createRequestContext\(\{[\s\S]*requestId: rid/);
  assert.match(app, /Object\.defineProperty\(req, ['"]context['"]/, 'request context should be non-enumerable transport metadata');
  assert.match(app, /writable: false/);
});
